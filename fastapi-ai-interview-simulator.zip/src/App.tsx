import { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Interviews from './pages/Interviews';
import NewInterview from './pages/NewInterview';
import InterviewSession from './pages/InterviewSession';
import Analytics from './pages/Analytics';
import Profile from './pages/Profile';
import Login from './pages/Login';
import Register from './pages/Register';

export type Page = 'dashboard' | 'interviews' | 'new-interview' | 'interview-session' | 'analytics' | 'profile' | 'login' | 'register';

export interface User {
  id: number;
  email: string;
  username: string;
  full_name: string;
  avatar_url?: string;
}

export interface Interview {
  id: number;
  title: string;
  interview_type: string;
  difficulty: string;
  status: string;
  total_questions: number;
  answered_questions: number;
  average_score: number;
  created_at: string;
  completed_at?: string;
}

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(true); // Demo mode
  const [user, setUser] = useState<User>({
    id: 1,
    email: 'demo@example.com',
    username: 'demo_user',
    full_name: 'Demo User'
  });
  const [selectedInterview, setSelectedInterview] = useState<Interview | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setIsAuthenticated(true);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser({
      id: 0,
      email: '',
      username: '',
      full_name: ''
    });
    setCurrentPage('login');
  };

  const handleStartInterview = (interview: Interview) => {
    setSelectedInterview(interview);
    setCurrentPage('interview-session');
  };

  if (!isAuthenticated) {
    if (currentPage === 'register') {
      return <Register onRegister={handleLogin} onSwitchToLogin={() => setCurrentPage('login')} />;
    }
    return <Login onLogin={handleLogin} onSwitchToRegister={() => setCurrentPage('register')} />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentPage} onStartInterview={handleStartInterview} />;
      case 'interviews':
        return <Interviews onNavigate={setCurrentPage} onStartInterview={handleStartInterview} />;
      case 'new-interview':
        return <NewInterview onNavigate={setCurrentPage} onStartInterview={handleStartInterview} />;
      case 'interview-session':
        return selectedInterview ? (
          <InterviewSession interview={selectedInterview} onComplete={() => setCurrentPage('interviews')} />
        ) : (
          <Dashboard onNavigate={setCurrentPage} onStartInterview={handleStartInterview} />
        );
      case 'analytics':
        return <Analytics />;
      case 'profile':
        return <Profile user={user} onUpdateUser={setUser} />;
      default:
        return <Dashboard onNavigate={setCurrentPage} onStartInterview={handleStartInterview} />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-900">
      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        user={user}
        onLogout={handleLogout}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
      />
      <main className={`flex-1 overflow-auto transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        {renderPage()}
      </main>
    </div>
  );
}

export default App;
