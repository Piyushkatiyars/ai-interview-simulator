import { useState } from 'react';

export default function Analytics() {
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');

  const overviewStats = {
    totalInterviews: 24,
    completedInterviews: 18,
    averageScore: 7.8,
    bestScore: 9.5,
    totalQuestions: 120,
    totalTime: 480
  };

  const skillData = [
    { name: 'HR & Behavioral', icon: '👥', interviews: 6, avgScore: 8.8, trend: 'up', color: 'from-blue-500 to-cyan-500' },
    { name: 'Python', icon: '🐍', interviews: 8, avgScore: 8.2, trend: 'up', color: 'from-yellow-500 to-green-500' },
    { name: 'Web Development', icon: '🌐', interviews: 5, avgScore: 7.4, trend: 'stable', color: 'from-purple-500 to-pink-500' },
    { name: 'Cloud Computing', icon: '☁️', interviews: 5, avgScore: 6.9, trend: 'down', color: 'from-cyan-500 to-blue-500' }
  ];

  const performanceData = [
    { date: 'Jan 1', python: 7.2, hr: 8.0, web: 6.5, cloud: 6.0 },
    { date: 'Jan 5', python: 7.5, hr: 8.2, web: 7.0, cloud: 6.2 },
    { date: 'Jan 10', python: 7.8, hr: 8.5, web: 7.2, cloud: 6.5 },
    { date: 'Jan 15', python: 8.0, hr: 8.8, web: 7.4, cloud: 6.8 },
    { date: 'Jan 20', python: 8.2, hr: 9.0, web: 7.5, cloud: 7.0 },
    { date: 'Jan 25', python: 8.4, hr: 9.2, web: 7.6, cloud: 6.9 }
  ];

  const weeklyActivity = [
    { day: 'Mon', interviews: 2 },
    { day: 'Tue', interviews: 3 },
    { day: 'Wed', interviews: 1 },
    { day: 'Thu', interviews: 4 },
    { day: 'Fri', interviews: 2 },
    { day: 'Sat', interviews: 5 },
    { day: 'Sun', interviews: 3 }
  ];

  const maxInterviews = Math.max(...weeklyActivity.map(d => d.interviews));

  const getGrade = (score: number) => {
    if (score >= 9) return { grade: 'A', color: 'text-emerald-400' };
    if (score >= 8) return { grade: 'B', color: 'text-blue-400' };
    if (score >= 7) return { grade: 'C', color: 'text-yellow-400' };
    if (score >= 6) return { grade: 'D', color: 'text-orange-400' };
    return { grade: 'F', color: 'text-red-400' };
  };

  const getTrendIcon = (trend: string) => {
    if (trend === 'up') return '📈';
    if (trend === 'down') return '📉';
    return '➡️';
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Analytics Dashboard</h1>
          <p className="text-slate-400">Track your interview performance and progress</p>
        </div>
        <div className="flex bg-slate-800 rounded-lg p-1">
          {(['7d', '30d', '90d'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                timeRange === range
                  ? 'bg-violet-500 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {range === '7d' ? '7 Days' : range === '30d' ? '30 Days' : '90 Days'}
            </button>
          ))}
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
          <p className="text-slate-400 text-sm mb-1">Total Interviews</p>
          <p className="text-2xl font-bold text-white">{overviewStats.totalInterviews}</p>
        </div>
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
          <p className="text-slate-400 text-sm mb-1">Completed</p>
          <p className="text-2xl font-bold text-emerald-400">{overviewStats.completedInterviews}</p>
        </div>
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
          <p className="text-slate-400 text-sm mb-1">Avg Score</p>
          <p className={`text-2xl font-bold ${getGrade(overviewStats.averageScore).color}`}>
            {overviewStats.averageScore}
          </p>
        </div>
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
          <p className="text-slate-400 text-sm mb-1">Best Score</p>
          <p className="text-2xl font-bold text-emerald-400">{overviewStats.bestScore}</p>
        </div>
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
          <p className="text-slate-400 text-sm mb-1">Questions</p>
          <p className="text-2xl font-bold text-blue-400">{overviewStats.totalQuestions}</p>
        </div>
        <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
          <p className="text-slate-400 text-sm mb-1">Time Spent</p>
          <p className="text-2xl font-bold text-purple-400">{Math.round(overviewStats.totalTime / 60)}h</p>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Performance Chart */}
        <div className="lg:col-span-2 bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Performance Trends</h2>
          
          {/* Simple Line Chart */}
          <div className="h-64 relative">
            <div className="absolute inset-0 flex items-end justify-between px-4">
              {performanceData.map((data, index) => (
                <div key={index} className="flex flex-col items-center space-y-2" style={{ height: '100%' }}>
                  <div className="flex-1 w-full flex items-end justify-center space-x-1">
                    <div
                      className="w-2 bg-gradient-to-t from-yellow-500 to-yellow-400 rounded-t"
                      style={{ height: `${data.python * 10}%` }}
                      title={`Python: ${data.python}`}
                    />
                    <div
                      className="w-2 bg-gradient-to-t from-blue-500 to-blue-400 rounded-t"
                      style={{ height: `${data.hr * 10}%` }}
                      title={`HR: ${data.hr}`}
                    />
                    <div
                      className="w-2 bg-gradient-to-t from-purple-500 to-purple-400 rounded-t"
                      style={{ height: `${data.web * 10}%` }}
                      title={`Web: ${data.web}`}
                    />
                    <div
                      className="w-2 bg-gradient-to-t from-cyan-500 to-cyan-400 rounded-t"
                      style={{ height: `${data.cloud * 10}%` }}
                      title={`Cloud: ${data.cloud}`}
                    />
                  </div>
                  <span className="text-xs text-slate-400">{data.date}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Legend */}
          <div className="flex justify-center space-x-6 mt-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded bg-yellow-500" />
              <span className="text-sm text-slate-400">Python</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded bg-blue-500" />
              <span className="text-sm text-slate-400">HR</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded bg-purple-500" />
              <span className="text-sm text-slate-400">Web</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded bg-cyan-500" />
              <span className="text-sm text-slate-400">Cloud</span>
            </div>
          </div>
        </div>

        {/* Weekly Activity */}
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Weekly Activity</h2>
          
          <div className="flex items-end justify-between h-48 mb-4">
            {weeklyActivity.map((day, index) => (
              <div key={index} className="flex flex-col items-center flex-1">
                <div className="w-full flex items-end justify-center h-40">
                  <div
                    className="w-8 bg-gradient-to-t from-violet-500 to-purple-400 rounded-t transition-all duration-300 hover:from-violet-400 hover:to-purple-300"
                    style={{ height: `${(day.interviews / maxInterviews) * 100}%` }}
                  />
                </div>
                <span className="text-xs text-slate-400 mt-2">{day.day}</span>
              </div>
            ))}
          </div>

          <div className="text-center pt-4 border-t border-slate-700">
            <p className="text-2xl font-bold text-white">
              {weeklyActivity.reduce((a, b) => a + b.interviews, 0)}
            </p>
            <p className="text-sm text-slate-400">interviews this week</p>
          </div>
        </div>
      </div>

      {/* Skill Analysis */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
        <h2 className="text-lg font-semibold text-white mb-6">Skill-wise Analysis</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {skillData.map((skill) => (
            <div
              key={skill.name}
              className="bg-slate-700/30 rounded-xl p-5 hover:bg-slate-700/50 transition-colors"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${skill.color} flex items-center justify-center text-2xl`}>
                  {skill.icon}
                </div>
                <span className="text-xl">{getTrendIcon(skill.trend)}</span>
              </div>

              <h3 className="font-medium text-white mb-1">{skill.name}</h3>
              <p className="text-sm text-slate-400 mb-4">{skill.interviews} interviews</p>

              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Avg Score</p>
                  <p className={`text-2xl font-bold ${getGrade(skill.avgScore).color}`}>
                    {skill.avgScore}
                  </p>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                  skill.trend === 'up' 
                    ? 'bg-emerald-500/20 text-emerald-400' 
                    : skill.trend === 'down'
                    ? 'bg-red-500/20 text-red-400'
                    : 'bg-slate-500/20 text-slate-400'
                }`}>
                  {skill.trend === 'up' ? '+0.5' : skill.trend === 'down' ? '-0.3' : '0.0'}
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mt-4">
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className={`h-full bg-gradient-to-r ${skill.color} rounded-full`}
                    style={{ width: `${skill.avgScore * 10}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Insights */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 border border-emerald-500/20 rounded-2xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <span className="text-2xl">🏆</span>
            <h3 className="text-lg font-semibold text-emerald-400">Top Performance</h3>
          </div>
          <p className="text-slate-300">
            Your <span className="text-white font-medium">HR & Behavioral</span> interviews have the highest average score at 8.8/10!
          </p>
        </div>

        <div className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border border-yellow-500/20 rounded-2xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <span className="text-2xl">🎯</span>
            <h3 className="text-lg font-semibold text-yellow-400">Focus Area</h3>
          </div>
          <p className="text-slate-300">
            <span className="text-white font-medium">Cloud Computing</span> needs attention. Consider practicing more in this area.
          </p>
        </div>

        <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-2xl p-6">
          <div className="flex items-center space-x-3 mb-4">
            <span className="text-2xl">📊</span>
            <h3 className="text-lg font-semibold text-blue-400">Progress</h3>
          </div>
          <p className="text-slate-300">
            You've improved by <span className="text-white font-medium">15%</span> compared to last month. Keep up the great work!
          </p>
        </div>
      </div>
    </div>
  );
}
