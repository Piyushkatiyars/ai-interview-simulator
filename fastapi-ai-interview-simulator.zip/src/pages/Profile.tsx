import { useState } from 'react';
import { User } from '../App';

interface ProfileProps {
  user: User;
  onUpdateUser: (user: User) => void;
}

export default function Profile({ user, onUpdateUser }: ProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    full_name: user.full_name,
    email: user.email,
    username: user.username,
    bio: 'Passionate developer focused on building great products',
    phone: '+1 234 567 890'
  });

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const achievements = [
    { id: 1, title: 'First Interview', description: 'Complete your first interview', icon: '🎯', completed: true },
    { id: 2, title: '5 Day Streak', description: 'Practice for 5 consecutive days', icon: '🔥', completed: true },
    { id: 3, title: 'Perfect Score', description: 'Get 10/10 on any question', icon: '⭐', completed: false },
    { id: 4, title: 'Python Master', description: 'Complete 10 Python interviews', icon: '🐍', completed: false },
    { id: 5, title: 'Well Rounded', description: 'Practice all interview types', icon: '🎭', completed: true },
    { id: 6, title: 'Speed Demon', description: 'Complete an interview in under 10 mins', icon: '⚡', completed: false }
  ];

  const stats = {
    totalInterviews: 24,
    avgScore: 7.8,
    streak: 5,
    questionsAnswered: 120,
    hoursSpent: 8,
    rank: 'Rising Star'
  };

  const handleSave = () => {
    onUpdateUser({
      ...user,
      full_name: formData.full_name,
      email: formData.email,
      username: formData.username
    });
    setIsEditing(false);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Profile Settings</h1>
        <p className="text-slate-400">Manage your account and preferences</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Profile */}
        <div className="lg:col-span-2 space-y-6">
          {/* Profile Card */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-white">Personal Information</h2>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isEditing
                    ? 'bg-slate-700 text-white'
                    : 'bg-violet-500/20 text-violet-400 hover:bg-violet-500/30'
                }`}
              >
                {isEditing ? 'Cancel' : 'Edit Profile'}
              </button>
            </div>

            <div className="flex items-start space-x-6 mb-8">
              <div className="relative">
                <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-4xl text-white font-bold">
                  {user.full_name.charAt(0).toUpperCase()}
                </div>
                {isEditing && (
                  <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-violet-500 rounded-full flex items-center justify-center text-white text-sm hover:bg-violet-600 transition-colors">
                    📷
                  </button>
                )}
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white">{user.full_name}</h3>
                <p className="text-slate-400">@{user.username}</p>
                <div className="flex items-center space-x-2 mt-2">
                  <span className="px-3 py-1 bg-violet-500/20 text-violet-400 text-xs font-medium rounded-full">
                    {stats.rank}
                  </span>
                  <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-medium rounded-full">
                    🔥 {stats.streak} day streak
                  </span>
                </div>
              </div>
            </div>

            {isEditing ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm text-slate-400 mb-2">Full Name</label>
                    <input
                      type="text"
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-violet-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-slate-400 mb-2">Username</label>
                    <input
                      type="text"
                      value={formData.username}
                      onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                      className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-violet-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-2">Email</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-violet-500"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-2">Bio</label>
                  <textarea
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    rows={3}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-violet-500 resize-none"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-2">Phone</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-violet-500"
                  />
                </div>
                <button
                  onClick={handleSave}
                  className="w-full py-3 bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-xl font-medium hover:from-violet-600 hover:to-purple-700 transition-all"
                >
                  Save Changes
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-700/30 rounded-xl">
                    <p className="text-sm text-slate-400">Full Name</p>
                    <p className="text-white font-medium">{formData.full_name}</p>
                  </div>
                  <div className="p-4 bg-slate-700/30 rounded-xl">
                    <p className="text-sm text-slate-400">Username</p>
                    <p className="text-white font-medium">@{formData.username}</p>
                  </div>
                </div>
                <div className="p-4 bg-slate-700/30 rounded-xl">
                  <p className="text-sm text-slate-400">Email</p>
                  <p className="text-white font-medium">{formData.email}</p>
                </div>
                <div className="p-4 bg-slate-700/30 rounded-xl">
                  <p className="text-sm text-slate-400">Bio</p>
                  <p className="text-white">{formData.bio}</p>
                </div>
                <div className="p-4 bg-slate-700/30 rounded-xl">
                  <p className="text-sm text-slate-400">Phone</p>
                  <p className="text-white font-medium">{formData.phone}</p>
                </div>
              </div>
            )}
          </div>

          {/* Change Password */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <h2 className="text-lg font-semibold text-white mb-6">Change Password</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-2">Current Password</label>
                <input
                  type="password"
                  value={passwordForm.currentPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-violet-500"
                  placeholder="••••••••"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-slate-400 mb-2">New Password</label>
                  <input
                    type="password"
                    value={passwordForm.newPassword}
                    onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-violet-500"
                    placeholder="••••••••"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-2">Confirm Password</label>
                  <input
                    type="password"
                    value={passwordForm.confirmPassword}
                    onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-violet-500"
                    placeholder="••••••••"
                  />
                </div>
              </div>
              <button className="px-6 py-3 bg-violet-500/20 text-violet-400 rounded-xl font-medium hover:bg-violet-500/30 transition-colors">
                Update Password
              </button>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Stats */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Your Stats</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-slate-700/30 rounded-xl">
                <span className="text-slate-400">Interviews</span>
                <span className="text-white font-bold">{stats.totalInterviews}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-700/30 rounded-xl">
                <span className="text-slate-400">Avg Score</span>
                <span className="text-blue-400 font-bold">{stats.avgScore}/10</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-700/30 rounded-xl">
                <span className="text-slate-400">Questions</span>
                <span className="text-white font-bold">{stats.questionsAnswered}</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-700/30 rounded-xl">
                <span className="text-slate-400">Hours Spent</span>
                <span className="text-purple-400 font-bold">{stats.hoursSpent}h</span>
              </div>
            </div>
          </div>

          {/* Achievements */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Achievements</h2>
            <div className="grid grid-cols-3 gap-3">
              {achievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className={`relative p-3 rounded-xl text-center transition-all ${
                    achievement.completed
                      ? 'bg-violet-500/20 border border-violet-500/30'
                      : 'bg-slate-700/30 opacity-50'
                  }`}
                  title={achievement.description}
                >
                  <span className="text-2xl">{achievement.icon}</span>
                  {achievement.completed && (
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
            <p className="text-sm text-slate-400 mt-4 text-center">
              {achievements.filter(a => a.completed).length}/{achievements.length} unlocked
            </p>
          </div>

          {/* Danger Zone */}
          <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-6">
            <h2 className="text-lg font-semibold text-red-400 mb-4">Danger Zone</h2>
            <p className="text-sm text-slate-400 mb-4">
              Once you delete your account, there is no going back. Please be certain.
            </p>
            <button className="w-full py-3 bg-red-500/20 text-red-400 rounded-xl font-medium hover:bg-red-500/30 transition-colors">
              Delete Account
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
