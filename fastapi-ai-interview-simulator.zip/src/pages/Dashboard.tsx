import { Page, Interview } from '../App';

interface DashboardProps {
  onNavigate: (page: Page) => void;
  onStartInterview: (interview: Interview) => void;
}

export default function Dashboard({ onNavigate, onStartInterview }: DashboardProps) {
  const stats = {
    totalInterviews: 24,
    completedInterviews: 18,
    averageScore: 7.8,
    currentStreak: 5,
    totalQuestions: 120,
    bestScore: 9.5
  };

  const recentInterviews: Interview[] = [
    {
      id: 1,
      title: 'Python Backend Interview',
      interview_type: 'python',
      difficulty: 'intermediate',
      status: 'completed',
      total_questions: 5,
      answered_questions: 5,
      average_score: 8.4,
      created_at: '2024-01-15T10:30:00Z',
      completed_at: '2024-01-15T11:15:00Z'
    },
    {
      id: 2,
      title: 'HR Behavioral Interview',
      interview_type: 'hr',
      difficulty: 'beginner',
      status: 'completed',
      total_questions: 5,
      answered_questions: 5,
      average_score: 9.2,
      created_at: '2024-01-14T14:00:00Z',
      completed_at: '2024-01-14T14:45:00Z'
    },
    {
      id: 3,
      title: 'Cloud Computing Basics',
      interview_type: 'cloud_computing',
      difficulty: 'beginner',
      status: 'in_progress',
      total_questions: 5,
      answered_questions: 3,
      average_score: 7.5,
      created_at: '2024-01-16T09:00:00Z'
    }
  ];

  const skillProgress = [
    { name: 'Python', score: 8.2, interviews: 8, icon: '🐍', color: 'from-yellow-400 to-yellow-600' },
    { name: 'HR & Behavioral', score: 8.8, interviews: 6, icon: '👥', color: 'from-blue-400 to-blue-600' },
    { name: 'Web Development', score: 7.4, interviews: 5, icon: '🌐', color: 'from-purple-400 to-purple-600' },
    { name: 'Cloud Computing', score: 6.9, interviews: 5, icon: '☁️', color: 'from-cyan-400 to-cyan-600' }
  ];

  const getTypeIcon = (type: string) => {
    const icons: Record<string, string> = {
      python: '🐍',
      hr: '👥',
      web_development: '🌐',
      cloud_computing: '☁️'
    };
    return icons[type] || '📝';
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      completed: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      in_progress: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      created: 'bg-slate-500/20 text-slate-400 border-slate-500/30'
    };
    return colors[status] || colors.created;
  };

  const getGrade = (score: number) => {
    if (score >= 9.5) return { grade: 'A+', color: 'text-emerald-400' };
    if (score >= 9) return { grade: 'A', color: 'text-emerald-400' };
    if (score >= 8.5) return { grade: 'B+', color: 'text-blue-400' };
    if (score >= 8) return { grade: 'B', color: 'text-blue-400' };
    if (score >= 7.5) return { grade: 'C+', color: 'text-yellow-400' };
    if (score >= 7) return { grade: 'C', color: 'text-yellow-400' };
    if (score >= 6) return { grade: 'D', color: 'text-orange-400' };
    return { grade: 'F', color: 'text-red-400' };
  };

  return (
    <div className="p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Welcome back! 👋</h1>
        <p className="text-slate-400">Track your progress and continue practicing</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-gradient-to-br from-violet-500/10 to-purple-500/10 border border-violet-500/20 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center">
              <span className="text-2xl">💼</span>
            </div>
            <span className="text-xs font-medium text-violet-400 bg-violet-500/20 px-2 py-1 rounded-full">
              +3 this week
            </span>
          </div>
          <h3 className="text-3xl font-bold text-white mb-1">{stats.totalInterviews}</h3>
          <p className="text-slate-400 text-sm">Total Interviews</p>
        </div>

        <div className="bg-gradient-to-br from-emerald-500/10 to-green-500/10 border border-emerald-500/20 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <span className="text-2xl">✅</span>
            </div>
            <span className="text-xs font-medium text-emerald-400 bg-emerald-500/20 px-2 py-1 rounded-full">
              75% rate
            </span>
          </div>
          <h3 className="text-3xl font-bold text-white mb-1">{stats.completedInterviews}</h3>
          <p className="text-slate-400 text-sm">Completed</p>
        </div>

        <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border border-blue-500/20 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center">
              <span className="text-2xl">⭐</span>
            </div>
            <span className={`text-xs font-medium ${getGrade(stats.averageScore).color} bg-blue-500/20 px-2 py-1 rounded-full`}>
              Grade {getGrade(stats.averageScore).grade}
            </span>
          </div>
          <h3 className="text-3xl font-bold text-white mb-1">{stats.averageScore}</h3>
          <p className="text-slate-400 text-sm">Average Score</p>
        </div>

        <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border border-orange-500/20 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 rounded-xl bg-orange-500/20 flex items-center justify-center">
              <span className="text-2xl">🔥</span>
            </div>
            <span className="text-xs font-medium text-orange-400 bg-orange-500/20 px-2 py-1 rounded-full">
              Keep going!
            </span>
          </div>
          <h3 className="text-3xl font-bold text-white mb-1">{stats.currentStreak}</h3>
          <p className="text-slate-400 text-sm">Day Streak</p>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Interviews */}
        <div className="lg:col-span-2 bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Recent Interviews</h2>
            <button
              onClick={() => onNavigate('interviews')}
              className="text-sm text-violet-400 hover:text-violet-300 transition-colors"
            >
              View All →
            </button>
          </div>

          <div className="space-y-4">
            {recentInterviews.map((interview) => (
              <div
                key={interview.id}
                className="flex items-center justify-between p-4 bg-slate-700/30 rounded-xl hover:bg-slate-700/50 transition-colors cursor-pointer"
                onClick={() => interview.status === 'in_progress' && onStartInterview(interview)}
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-600/50 flex items-center justify-center text-2xl">
                    {getTypeIcon(interview.interview_type)}
                  </div>
                  <div>
                    <h3 className="font-medium text-white">{interview.title}</h3>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className={`text-xs px-2 py-0.5 rounded-full border ${getStatusColor(interview.status)}`}>
                        {interview.status.replace('_', ' ')}
                      </span>
                      <span className="text-xs text-slate-400">
                        {interview.answered_questions}/{interview.total_questions} questions
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  {interview.status === 'completed' ? (
                    <div>
                      <span className={`text-2xl font-bold ${getGrade(interview.average_score).color}`}>
                        {interview.average_score.toFixed(1)}
                      </span>
                      <p className="text-xs text-slate-400">
                        Grade {getGrade(interview.average_score).grade}
                      </p>
                    </div>
                  ) : (
                    <button className="px-4 py-2 bg-violet-500 hover:bg-violet-600 text-white rounded-lg text-sm font-medium transition-colors">
                      Continue
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Skill Progress */}
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
          <h2 className="text-xl font-bold text-white mb-6">Skill Progress</h2>

          <div className="space-y-6">
            {skillProgress.map((skill) => (
              <div key={skill.name}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">{skill.icon}</span>
                    <span className="text-sm font-medium text-white">{skill.name}</span>
                  </div>
                  <span className="text-sm font-bold text-white">{skill.score.toFixed(1)}</span>
                </div>
                <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className={`h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-500`}
                    style={{ width: `${skill.score * 10}%` }}
                  />
                </div>
                <p className="text-xs text-slate-400 mt-1">{skill.interviews} interviews</p>
              </div>
            ))}
          </div>

          <button
            onClick={() => onNavigate('new-interview')}
            className="w-full mt-6 py-3 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white rounded-xl font-medium transition-all duration-200 flex items-center justify-center space-x-2"
          >
            <span>➕</span>
            <span>Start New Interview</span>
          </button>
        </div>
      </div>

      {/* Recommendations */}
      <div className="mt-6 bg-gradient-to-r from-violet-500/10 to-purple-500/10 border border-violet-500/20 rounded-2xl p-6">
        <h2 className="text-xl font-bold text-white mb-4">💡 Recommendations</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <p className="text-slate-300 text-sm">
              📚 Focus on <span className="text-cyan-400 font-medium">Cloud Computing</span> - your average score is 6.9/10
            </p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <p className="text-slate-300 text-sm">
              🔥 Great job! <span className="text-orange-400 font-medium">{stats.currentStreak} day streak</span> - keep it up!
            </p>
          </div>
          <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
            <p className="text-slate-300 text-sm">
              ⏰ It's been a while since you practiced <span className="text-purple-400 font-medium">Web Development</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
