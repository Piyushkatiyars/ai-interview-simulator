import { useState } from 'react';
import { Interview } from '../App';

interface InterviewSessionProps {
  interview: Interview;
  onComplete: () => void;
}

interface Question {
  id: number;
  number: number;
  text: string;
  type: string;
}

interface Evaluation {
  score: number;
  feedback: string;
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
}

export default function InterviewSession({ interview, onComplete }: InterviewSessionProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [evaluation, setEvaluation] = useState<Evaluation | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [completedQuestions, setCompletedQuestions] = useState<number[]>([]);
  const [scores, setScores] = useState<number[]>([]);
  const [isComplete, setIsComplete] = useState(false);

  const sampleQuestions: Record<string, Question[]> = {
    python: [
      { id: 1, number: 1, text: "Explain the difference between lists and tuples in Python. When would you use each?", type: "open_ended" },
      { id: 2, number: 2, text: "What are Python decorators and how do they work? Provide an example use case.", type: "open_ended" },
      { id: 3, number: 3, text: "Explain the GIL (Global Interpreter Lock) in Python. What are its implications?", type: "open_ended" },
      { id: 4, number: 4, text: "What is the difference between deep copy and shallow copy in Python?", type: "open_ended" },
      { id: 5, number: 5, text: "How does garbage collection work in Python? Explain reference counting.", type: "open_ended" }
    ],
    hr: [
      { id: 1, number: 1, text: "Tell me about yourself and your professional background.", type: "open_ended" },
      { id: 2, number: 2, text: "Describe a challenging situation at work and how you handled it.", type: "open_ended" },
      { id: 3, number: 3, text: "Why do you want to work for our company?", type: "open_ended" },
      { id: 4, number: 4, text: "Where do you see yourself in 5 years?", type: "open_ended" },
      { id: 5, number: 5, text: "How do you handle stress and pressure at work?", type: "open_ended" }
    ],
    web_development: [
      { id: 1, number: 1, text: "Explain the difference between REST and GraphQL APIs.", type: "open_ended" },
      { id: 2, number: 2, text: "What is the Virtual DOM and how does React use it?", type: "open_ended" },
      { id: 3, number: 3, text: "Explain CSS Flexbox and when you would use it.", type: "open_ended" },
      { id: 4, number: 4, text: "What are Web Workers and when would you use them?", type: "open_ended" },
      { id: 5, number: 5, text: "Explain the concept of CORS and how to handle it.", type: "open_ended" }
    ],
    cloud_computing: [
      { id: 1, number: 1, text: "Explain the difference between IaaS, PaaS, and SaaS.", type: "open_ended" },
      { id: 2, number: 2, text: "What is containerization and how does Docker work?", type: "open_ended" },
      { id: 3, number: 3, text: "Explain the concept of auto-scaling in cloud environments.", type: "open_ended" },
      { id: 4, number: 4, text: "What is Infrastructure as Code and why is it important?", type: "open_ended" },
      { id: 5, number: 5, text: "Explain the CAP theorem and its implications.", type: "open_ended" }
    ]
  };

  const questions = sampleQuestions[interview.interview_type] || sampleQuestions.hr;
  const currentQuestion = questions[currentQuestionIndex];
  const totalQuestions = Math.min(interview.total_questions, questions.length);

  const handleSubmitAnswer = async () => {
    if (!answer.trim()) return;

    setIsSubmitting(true);

    // Simulate AI evaluation
    await new Promise(resolve => setTimeout(resolve, 2000));

    const wordCount = answer.split(' ').length;
    let score = 5;
    if (wordCount > 50) score += 1.5;
    if (wordCount > 100) score += 1;
    if (wordCount > 150) score += 0.5;
    score = Math.min(score + Math.random() * 2, 10);
    score = parseFloat(score.toFixed(1));

    const mockEvaluation: Evaluation = {
      score,
      feedback: "Your answer demonstrates a good understanding of the concept. You've covered the key points effectively and provided relevant context.",
      strengths: [
        "Clear and structured explanation",
        "Good use of technical terminology",
        "Logical flow of ideas"
      ],
      weaknesses: [
        "Could include more specific examples",
        "Consider adding real-world applications"
      ],
      suggestions: [
        "Practice explaining with code examples",
        "Relate concepts to practical scenarios",
        "Review advanced topics in this area"
      ]
    };

    setEvaluation(mockEvaluation);
    setScores([...scores, score]);
    setCompletedQuestions([...completedQuestions, currentQuestionIndex]);
    setShowFeedback(true);
    setIsSubmitting(false);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex + 1 >= totalQuestions) {
      setIsComplete(true);
    } else {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setAnswer('');
      setEvaluation(null);
      setShowFeedback(false);
    }
  };

  const getGrade = (score: number) => {
    if (score >= 9.5) return { grade: 'A+', color: 'text-emerald-400', bg: 'bg-emerald-500/20' };
    if (score >= 9) return { grade: 'A', color: 'text-emerald-400', bg: 'bg-emerald-500/20' };
    if (score >= 8.5) return { grade: 'B+', color: 'text-blue-400', bg: 'bg-blue-500/20' };
    if (score >= 8) return { grade: 'B', color: 'text-blue-400', bg: 'bg-blue-500/20' };
    if (score >= 7.5) return { grade: 'C+', color: 'text-yellow-400', bg: 'bg-yellow-500/20' };
    if (score >= 7) return { grade: 'C', color: 'text-yellow-400', bg: 'bg-yellow-500/20' };
    if (score >= 6) return { grade: 'D', color: 'text-orange-400', bg: 'bg-orange-500/20' };
    return { grade: 'F', color: 'text-red-400', bg: 'bg-red-500/20' };
  };

  const averageScore = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;

  if (isComplete) {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
            <span className="text-4xl">🎉</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Interview Complete!</h1>
          <p className="text-slate-400">Great job! Here's your performance summary</p>
        </div>

        {/* Overall Score */}
        <div className="bg-gradient-to-br from-violet-500/10 to-purple-500/10 border border-violet-500/20 rounded-2xl p-8 mb-8 text-center">
          <h2 className="text-lg text-slate-400 mb-2">Overall Score</h2>
          <div className={`text-6xl font-bold mb-2 ${getGrade(averageScore).color}`}>
            {averageScore.toFixed(1)}
          </div>
          <div className={`inline-block px-4 py-2 rounded-full ${getGrade(averageScore).bg} ${getGrade(averageScore).color}`}>
            Grade: {getGrade(averageScore).grade}
          </div>
        </div>

        {/* Question Breakdown */}
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6 mb-8">
          <h3 className="text-lg font-semibold text-white mb-4">Question Breakdown</h3>
          <div className="space-y-3">
            {scores.map((score, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-xl">
                <span className="text-slate-400">Question {index + 1}</span>
                <div className="flex items-center space-x-3">
                  <div className="w-32 h-2 bg-slate-700 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        score >= 8 ? 'bg-emerald-500' : score >= 6 ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${score * 10}%` }}
                    />
                  </div>
                  <span className={`font-bold ${getGrade(score).color}`}>{score.toFixed(1)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-emerald-400 mb-4 flex items-center space-x-2">
              <span>✅</span>
              <span>Strengths</span>
            </h3>
            <ul className="space-y-2">
              <li className="text-slate-300 text-sm">• Clear communication skills</li>
              <li className="text-slate-300 text-sm">• Good technical understanding</li>
              <li className="text-slate-300 text-sm">• Structured responses</li>
            </ul>
          </div>
          <div className="bg-orange-500/10 border border-orange-500/20 rounded-2xl p-6">
            <h3 className="text-lg font-semibold text-orange-400 mb-4 flex items-center space-x-2">
              <span>📈</span>
              <span>Areas to Improve</span>
            </h3>
            <ul className="space-y-2">
              <li className="text-slate-300 text-sm">• Include more specific examples</li>
              <li className="text-slate-300 text-sm">• Add practical applications</li>
              <li className="text-slate-300 text-sm">• Deepen technical knowledge</li>
            </ul>
          </div>
        </div>

        <button
          onClick={onComplete}
          className="w-full py-4 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white rounded-xl font-medium transition-all"
        >
          Back to Interviews
        </button>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white">{interview.title}</h1>
          <p className="text-slate-400">Question {currentQuestionIndex + 1} of {totalQuestions}</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <p className="text-sm text-slate-400">Progress</p>
            <p className="text-lg font-bold text-white">
              {Math.round((completedQuestions.length / totalQuestions) * 100)}%
            </p>
          </div>
          <button
            onClick={onComplete}
            className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm transition-colors"
          >
            Exit
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="h-2 bg-slate-700 rounded-full mb-8 overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-violet-500 to-purple-500 transition-all duration-500"
          style={{ width: `${((completedQuestions.length) / totalQuestions) * 100}%` }}
        />
      </div>

      {/* Question Card */}
      <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-8 mb-6">
        <div className="flex items-start space-x-4 mb-6">
          <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center text-violet-400 font-bold">
            Q{currentQuestionIndex + 1}
          </div>
          <div className="flex-1">
            <p className="text-xl text-white leading-relaxed">{currentQuestion.text}</p>
          </div>
        </div>

        {!showFeedback ? (
          <>
            <textarea
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="Type your answer here..."
              rows={8}
              className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-colors resize-none"
            />
            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-slate-400">
                {answer.split(' ').filter(w => w.length > 0).length} words
              </p>
              <button
                onClick={handleSubmitAnswer}
                disabled={!answer.trim() || isSubmitting}
                className={`px-6 py-3 rounded-xl font-medium transition-all flex items-center space-x-2 ${
                  !answer.trim() || isSubmitting
                    ? 'bg-slate-700 text-slate-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white'
                }`}
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    <span>Evaluating...</span>
                  </>
                ) : (
                  <>
                    <span>Submit Answer</span>
                    <span>→</span>
                  </>
                )}
              </button>
            </div>
          </>
        ) : evaluation && (
          <div className="space-y-6">
            {/* Score */}
            <div className={`p-6 rounded-xl ${getGrade(evaluation.score).bg} border border-slate-600`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400 mb-1">Your Score</p>
                  <p className={`text-4xl font-bold ${getGrade(evaluation.score).color}`}>
                    {evaluation.score.toFixed(1)}/10
                  </p>
                </div>
                <div className={`text-6xl font-bold ${getGrade(evaluation.score).color}`}>
                  {getGrade(evaluation.score).grade}
                </div>
              </div>
            </div>

            {/* Feedback */}
            <div className="p-4 bg-slate-700/30 rounded-xl">
              <h4 className="text-sm font-medium text-slate-400 mb-2">AI Feedback</h4>
              <p className="text-white">{evaluation.feedback}</p>
            </div>

            {/* Strengths & Weaknesses */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/20">
                <h4 className="text-sm font-medium text-emerald-400 mb-2">✅ Strengths</h4>
                <ul className="space-y-1">
                  {evaluation.strengths.map((s, i) => (
                    <li key={i} className="text-sm text-slate-300">• {s}</li>
                  ))}
                </ul>
              </div>
              <div className="p-4 bg-orange-500/10 rounded-xl border border-orange-500/20">
                <h4 className="text-sm font-medium text-orange-400 mb-2">📈 Improvements</h4>
                <ul className="space-y-1">
                  {evaluation.weaknesses.map((w, i) => (
                    <li key={i} className="text-sm text-slate-300">• {w}</li>
                  ))}
                </ul>
              </div>
            </div>

            <button
              onClick={handleNextQuestion}
              className="w-full py-3 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white rounded-xl font-medium transition-all"
            >
              {currentQuestionIndex + 1 >= totalQuestions ? 'Complete Interview' : 'Next Question →'}
            </button>
          </div>
        )}
      </div>

      {/* Question Navigation */}
      <div className="flex space-x-2">
        {Array.from({ length: totalQuestions }).map((_, index) => (
          <div
            key={index}
            className={`w-10 h-10 rounded-lg flex items-center justify-center text-sm font-medium transition-all ${
              completedQuestions.includes(index)
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : index === currentQuestionIndex
                ? 'bg-violet-500 text-white'
                : 'bg-slate-700 text-slate-400'
            }`}
          >
            {completedQuestions.includes(index) ? '✓' : index + 1}
          </div>
        ))}
      </div>
    </div>
  );
}
